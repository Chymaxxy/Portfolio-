// The twin answers ONLY from these facts. Edit, add or delete lines freely.
// Each fact is one short, self-contained sentence, so the search can match it on meaning.
// "tag" is the topic label shown under an answer.

export const FACTS = [
  // About
  { tag: "About", text: "My name is Amaka. My full name is Chiamaka Odirih Benedette." },
  { tag: "About", text: "I am an independent AI automation consultant and I run a brand called iDigitals." },
  { tag: "About", text: "I am based in Lagos, Nigeria." },
  { tag: "About", text: "I build real projects for real clients and share my progress publicly on LinkedIn and X with the hashtags iDigitals, AIAutomation and BuildingInPublic." },

  // Background
  { tag: "Background", text: "My degree is in English Language and Education." },
  { tag: "Background", text: "I started with a background in English and copywriting." },
  { tag: "Background", text: "I bring copywriting into my automation work. I write the words the AI says, so automated messages sound human and match the client's business." },

  // Services
  { tag: "Services", text: "iDigitals offers three services: custom AI agent development, automation workflows, and consultation and training." },
  { tag: "Services", text: "I build custom AI agents that answer questions, sort requests and hand over to a person when needed." },
  { tag: "Services", text: "I build automation workflows that connect the tools a business already uses, so repeat tasks run on their own." },
  { tag: "Services", text: "I offer consultation and training, helping a team work out what to automate first and teaching them to run it." },

  // Tools
  { tag: "Tools", text: "My main automation tool is n8n. I also work with HubSpot, Slack, Gmail, Google Sheets, Google Docs, WhatsApp and Dropbox." },

  // Projects
  { tag: "Project", text: "Lead scoring project: new web-form leads are scored and categorised by AI, saved to HubSpot, and hot leads trigger an alert in Slack straight away. Built with n8n." },
  { tag: "Project", text: "Missed-call project: for a dental practice, when a call goes unanswered the caller is automatically sent a text message, and the missed number is logged along with whether a text was sent. Built with n8n." },
  { tag: "Project", text: "Customer support chatbot project: an AI customer support chatbot for Lochids Limited, a Nigerian food company, built in n8n Cloud." },
  { tag: "Project", text: "Inquiry triage project: an AI-powered system for a home services company that reads incoming inquiries, sorts them and routes them to the right person." },
  { tag: "Project", text: "Email to spreadsheet project: for an operations team, a labelled Gmail email is summarised by AI and added as a row in a tracking Google Sheet." },
  { tag: "Project", text: "Spreadsheet to document project: for an operations team, a new row in a Google Sheet makes AI draft a Google Doc from a template." },
  { tag: "Project", text: "Product photo project: raw product photos dropped in Dropbox are automatically cleaned up, resized and standardised, then saved to a ready folder while the originals are kept." },
  { tag: "Project", text: "Travel agency project: customers of a travel agency automatically get WhatsApp messages before and after their trip, driven by the trip spreadsheet." },
  { tag: "Project", text: "Proposal email project: when someone emails iDigitals asking for a proposal or a deck, an automatic reply is sent that sounds like me." },

  // Contact
  { tag: "Contact", text: "The best way to reach me is on LinkedIn: https://www.linkedin.com/in/chiamaka-odirih-ab041b263" }

  // TODO (add when you are ready, one sentence each):
  // - certifications and courses
  // - years of experience
  // - how you price and how a project starts
  // - industries you have worked in
  // - what you do not do
];
