// AI twin: semantic search over knowledge.js, running fully in the browser.
// A small model (all-MiniLM-L6-v2) turns each fact and each question into numbers,
// then the closest facts are shown. If the model can't load, simple keyword search takes over.

import { FACTS } from "./knowledge.js";

const msgs = document.getElementById("msgs");
const form = document.getElementById("askForm");
const input = document.getElementById("askInput");
const btn = document.getElementById("askBtn");
const status = document.getElementById("status");
const asks = document.getElementById("asks");

const MIN_SCORE = 0.3; // below this the twin says it doesn't know
const TOP_N = 2;

let embed = null;      // the model, once loaded
let vectors = null;    // one vector per fact

function add(cls, text, source) {
  const d = document.createElement("div");
  d.className = "b " + cls;
  d.textContent = text;
  if (source) {
    const s = document.createElement("span");
    s.className = "src";
    s.textContent = source;
    d.appendChild(s);
  }
  msgs.appendChild(d);
  d.scrollIntoView({ block: "nearest" });
}

function dot(a, b) {
  let s = 0;
  for (let i = 0; i < a.length; i++) s += a[i] * b[i];
  return s;
}

// ---- keyword fallback ----
const STOP = new Set("a an the and or of to in on for with is are was do does did you your i me my what how why who where when can about tell it this that".split(" "));
function words(t) {
  return t.toLowerCase().replace(/[^a-z0-9 ]/g, " ").split(/\s+/).filter(w => w && !STOP.has(w));
}
function keywordScores(q) {
  const qw = new Set(words(q));
  return FACTS.map(f => {
    const fw = words(f.text);
    let hits = 0;
    fw.forEach(w => { if (qw.has(w)) hits++; });
    return qw.size ? hits / Math.sqrt(fw.length * qw.size) : 0;
  });
}

async function scores(q) {
  if (embed) {
    const out = await embed(q, { pooling: "mean", normalize: true });
    return { s: vectors.map(v => dot(v, out.data)), min: MIN_SCORE };
  }
  return { s: keywordScores(q), min: 0.12 };
}

async function answer(q) {
  const { s, min } = await scores(q);
  const ranked = s.map((v, i) => [v, i]).sort((a, b) => b[0] - a[0]);
  const good = ranked.filter(r => r[0] >= min).slice(0, TOP_N);
  if (!good.length) {
    add("ai", "I don't have that in my profile yet. You can ask me about my projects, services, background or tools, or message me on LinkedIn.");
    return;
  }
  const text = good.map(r => FACTS[r[1]].text).join(" ");
  const tags = [...new Set(good.map(r => FACTS[r[1]].tag))].join(", ");
  add("ai", text, "From my profile: " + tags);
}

async function ask(q) {
  q = q.trim();
  if (!q) return;
  add("me", q);
  input.value = "";
  btn.disabled = true;
  try { await answer(q); } finally { btn.disabled = false; }
}

form.addEventListener("submit", e => { e.preventDefault(); ask(input.value); });
asks.addEventListener("click", e => {
  const b = e.target.closest("button");
  if (b) ask(b.textContent);
});

// ---- load the model ----
async function load() {
  try {
    const { pipeline, env } = await import("https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.2");
    env.allowLocalModels = false;
    const model = await pipeline("feature-extraction", "Xenova/all-MiniLM-L6-v2");
    const vecs = [];
    for (const f of FACTS) {
      const out = await model(f.text, { pooling: "mean", normalize: true });
      vecs.push(out.data);
    }
    vectors = vecs;
    embed = model;
    status.textContent = "Ready. Search by meaning is on.";
  } catch (err) {
    console.error(err);
    embed = null;
    status.textContent = "Ready. Using simple keyword search because the AI model couldn't load.";
  }
}
load();
